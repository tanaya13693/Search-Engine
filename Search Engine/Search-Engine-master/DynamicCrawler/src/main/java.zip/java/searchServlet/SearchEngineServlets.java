
package searchServlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import indexing.Indexer;
import indexing.ReadDocuments;
import pageRank.PageRank;
import pageRank.WebGraph;
import search.Search;
import search.SearchResult;

/**
 * Servlet implementation class SearchEngineServlets
 */
@WebServlet("/SearchEngineServlets")
public class SearchEngineServlets extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	public static final String INDEX_DIR = "/Users/vikashkumar/Documents/IR/IndexDir";
	//public static final String dirPath = "/Users/vikashkumar/Documents/IR/sampleDownload";
	public static final String dirPath = "/Users/vikashkumar/Documents/IR/Download";
	public static int tfidfScoring;
	public static int pageRankScoring;
	public static int tfidfPageRankScoring;

    /**
     * Default constructor. 
     */
    public SearchEngineServlets() 
    {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		System.out.println("Hello World");

		String query = request.getParameter("query");
		System.out.println("Query obtained: " + query );
		
		if( query == null )
		{
			RequestDispatcher rd = request.getRequestDispatcher("/searchPage.jsp");
			rd.forward(request, response);
		}
		else
		{
			String radio1 = request.getParameter("radioOption");
					
			System.out.println(" Radio1: " + radio1 );
			
			if( radio1 != null && radio1.equals( "1" ) )
			{
				tfidfScoring = 1;
				pageRankScoring = 0;
				tfidfPageRankScoring = 0;
			}
			else if( radio1 != null && radio1.equals( "2" ) )
			{
				tfidfScoring = 0;
				pageRankScoring = 1;
				tfidfPageRankScoring = 0;
			}
			else if( radio1 != null && radio1.equals( "3" ) )
			{
				tfidfScoring = 0;
				pageRankScoring = 0;
				tfidfPageRankScoring = 1;
			}
			
			
			ReadDocuments readDoc = new ReadDocuments( dirPath );
			// Getting all File paths and URL list stored on directory and url downloaded files
			readDoc.readAllFilesFromDir();
			
			readDoc.parseDocuments();
			
			// PageRank calculation
			WebGraph graph = new WebGraph();
			graph.createWebGrpahOfAllPages( readDoc.filePaths, readDoc.urlList );
			graph.printGraph( WebGraph.WebGraph );
			graph.printGraph( WebGraph.mInComingLinks );
			PageRank pr = new PageRank( WebGraph.WebGraph, WebGraph.mInComingLinks);
			pr.calculatePageRank();
			
			//pr.printFinalPageRank();
			
			// Indexing
			Indexer indexer = new Indexer();
			indexer.createIndex(readDoc.webDocuments );
			
			Search search = new Search();
			List<SearchResult> searchResults = search.search( query, 10, readDoc.filePaths, readDoc.urlList );
			//List<SearchResult> newSearchResults;
			
			if( pageRankScoring == 1 || tfidfPageRankScoring == 1 )
			{
				searchResults = search.calculateNewScore( searchResults, PageRank.PageRank );
			}

			RequestDispatcher rd = request.getRequestDispatcher("/searchResult.jsp");
			request.setAttribute( "searchResults", searchResults );
			rd.forward(request, response);
		}
		
	}
	
	protected void controllerSearchEngine( String query )
	{
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
