package indexing;

public class WebDocuments 
{
	public String title;
	public String body;
	public String fileName;
	public String metaData;
	
	public WebDocuments( String title, String body, String fileName, String metaData )
	{
		this.title = title;
		this.body = body;
		this.fileName = fileName;
		this.metaData = metaData;
	}
}
